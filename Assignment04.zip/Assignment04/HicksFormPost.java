/* Create a Servlet that displays a form when the doGet method is invoked. The 
form will contain a post action that directs the form post back to the same 
servlet, which in the doPost method will append the form data to a random access 
file. After the form data has been appended to the file, respond back with the 
complete contents of the data file. The form must contain a minimum of three 
input fields. The grade for this assignment will be based both on the 
functionality of the servlet and the appearance of the form post results. Name 
your servlet HicksFormPost and name the random access data file 
c:\temp\HicksWeek4.dat. You must locate the file in the c:\temp directory 
to receive credit. This is so I can run and grade it on my computer without 
modifying your source code. Attach your servlet source code file and random 
access data file to this assignment in one zipped file. Do not copy 
(cut and paste) any example code, create your own code and use the examples as a 
guide.*/
package Assignment04;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "HicksFormPost", urlPatterns = {"/HicksFormPost", "/HicksFormPost1",
    "/HicksFormPost2", "/HicksFormPost3"})
public class HicksFormPost extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");

        PrintWriter out = response.getWriter();

        out.println("<!DOCTYPE html>");
        out.println("<html lang='en'>");
        out.println("<title>");
        out.println("Form Post");
        out.println("</title>");
        out.println("<body>");
        out.println("<div>");

        out.println("<form method='post' action='/Assignment04/HicksFormPost1'>");
        out.println("<label> Enter text for form 1 : </label>");
        out.println("<input type='text' name='myForm' size='40' maxlength='40' />");
        out.println("<input type='submit' value='Form 1'/>");
        out.println("</form>");

        out.println("<form method='post' action='/Assignment04/HicksFormPost2'>");
        out.println("<label> Enter text for form 2 : </label>");
        out.println("<input type='text' name='myForm' size='40' maxlength='40' />");
        out.println("<input type='submit' value='Form 2' />");
        out.println("</form>");

        out.println("<form method='post' action='/Assignment04/HicksFormPost3'>");
        out.println("<label> Enter text for form 3 : </label>");
        out.println("<input type='text' name='myForm' size='40' maxlength='40' />");
        out.println("<input type='submit' value='Form 3' />");
        out.println("</form>");

        out.println("</div>");
        out.println("</body>");
        out.println("</html>");

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws
            ServletException, IOException {

        final int bufferLength = 41;
        String data = null;
        RandomAccessFile randomAccessFile = new RandomAccessFile("C:/temp/HicksWeek4.dat", "rw");
        StringBuffer buffer = new StringBuffer(request.getParameter("myForm"));

        response.setContentType("text/html");

        PrintWriter out = response.getWriter();

        String uri = request.getRequestURI();

        out.println("<!DOCTYPE html>");
        out.println("<html lang='en'>");
        out.println("<title>");
        out.println("Form Post");
        out.println("</title>");
        out.println("<body>");
        out.println("<div>");

        //Displays which form was selected by the user with url pattern
        if (uri.endsWith("/HicksFormPost1")) {

            out.println("Form 1");
        } else if (uri.endsWith("/HicksFormPost2")) {

            out.println("Form 2");
        } else {

            out.println("Form 3");
        }
        
        out.println("<form method='post' action='/Assignment04/HicksFormPost1'>");
        out.println("<label> Enter text for form 1 : </label>");
        out.println("<input type='text' name='myForm' size='40' maxlength='40' />");
        out.println("<input type='submit' value='Form 1'/>");
        out.println("</form>");

        out.println("<form method='post' action='/Assignment04/HicksFormPost2'>");
        out.println("<label> Enter text for form 2 : </label>");
        out.println("<input type='text' name='myForm' size='40' maxlength='40' />");
        out.println("<input type='submit' value='Form 2' />");
        out.println("</form>");

        out.println("<form method='post' action='/Assignment04/HicksFormPost3'>");
        out.println("<label> Enter text for form 3 : </label>");
        out.println("<input type='text' name='myForm' size='40' maxlength='40' />");
        out.println("<input type='submit' value='Form 3' />");
        out.println("</form>");

        //sets buffer length, trims characters to buffer length - 1
        buffer.setLength(bufferLength);
        buffer.setCharAt(bufferLength - 1, '\n');

        //Returns length of the random access file, writes the file, resets pointer to 0
        randomAccessFile.seek(randomAccessFile.length());
        randomAccessFile.writeChars(buffer.toString());
        randomAccessFile.seek(0);

        //Reads the random access file
        while ((data = randomAccessFile.readLine()) != null) {

            out.println(data + "<br />");
        }

        out.println("</div>");
        out.println("</body>");
        out.println("</html>");
    }
}
