/* Record class to hold a single selection of address table data
 * Mostly getters and setters with an overloaded toString() method */

public class Assignment02Record {

	String firstName;
	String lastName;
	String city;
	String state;
	String zip;

	public String getFirstName() {

		return firstName;
	}

	public void setFirstName(String firstName) {

		this.firstName = new String(firstName);
	}

	public String getLastName() {

		return lastName;
	}

	public void setLastName(String lastName) {

		this.lastName = new String(lastName);
	}

	public String getCity() {

		return city;
	}

	public void setCity(String city) {

		this.city = new String(city);
	}

	public String getState() {

		return state;
	}

	public void setState(String state) {

		this.state = new String(state);
	}

	public String getZip() {

		return zip;
	}

	public void setZip(String zip) {

		this.zip = new String(zip);
	}

	public String toString() {

		return new String(firstName.toString().trim() + ", " + lastName.toString().trim() + ", "
				+ city.toString().trim() + ", " + state.toString().trim() + ", " + zip.toString().trim());
	}
}