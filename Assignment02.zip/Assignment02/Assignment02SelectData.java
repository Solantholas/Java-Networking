/* Class for managing Oracle DB connection, and query the database.
 * Logic methods to get table cells and assign to myRecord objects. */

import java.net.URL;
import java.sql.*;
import oracle.jdbc.OracleResultSetMetaData;

public class Assignment02SelectData {

	// Creates new interface sessions
	Connection con;
	Statement stmt;
	ResultSet resultSet;

	public Assignment02SelectData() {

		try {
			// DriverManager interface manages driver connections.
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());

			// Retrieves Oracle Thin Driver on local host at port 1521 with SID set to xe
			// and student1 user/password. Sets to connection con.
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "student1", "pass");

			/* Creates statement that will generate resultSet objects with defined type and
			 * concurrency Scroll insensitive means the ResultSet can scroll but is
			 * insensitive to changes Read only means the ResultSet may not be updated */
			stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);

		} catch (Exception e) {
			// Throws console error printout if connection to database fails
			System.out.println(e);
			System.out.println("Error connection to database.");
			System.exit(0);
		}
		try {	// Attempts to query the database with a SELECT SQL statement
				// Assigns SQL statement to resultSet object
			resultSet = stmt.executeQuery("SELECT * FROM address ORDER BY id");
		} catch (SQLException e) {
			// Throws console error if SQL statement fails
			System.out.println(e);
			System.out.println("Result Request Failed");
		}
	}

	public Assignment02Record getReset() { // Defines getReset method

		Assignment02Record myRecord = new Assignment02Record(); // Creates new Record object

		try { 	// Attempts to call resultSet.first method to move cursor to first row in the
				// resultset object
			resultSet.first();

			// Finds given column names and assigns values to myRecord object
			myRecord.setFirstName(resultSet.getString(resultSet.findColumn("FIRSTNAME")));
			myRecord.setLastName(resultSet.getString(resultSet.findColumn("LASTNAME")));
			myRecord.setCity(resultSet.getString(resultSet.findColumn("CITY")));
			myRecord.setState(resultSet.getString(resultSet.findColumn("STATE")));
			myRecord.setZip(resultSet.getString(resultSet.findColumn("ZIP")));
		} catch (Exception e) {

			System.out.println(e);
		}

		return myRecord;
	}

	public Assignment02Record getNext() {

		Assignment02Record myRecord = new Assignment02Record();

		try { 	// Attempts to call resultSet.next method to move cursor forward one row in the
				// resultset object
			resultSet.next();

			myRecord.setFirstName(resultSet.getString(resultSet.findColumn("FIRSTNAME")));
			myRecord.setLastName(resultSet.getString(resultSet.findColumn("LASTNAME")));
			myRecord.setCity(resultSet.getString(resultSet.findColumn("CITY")));
			myRecord.setState(resultSet.getString(resultSet.findColumn("STATE")));
			myRecord.setZip(resultSet.getString(resultSet.findColumn("ZIP")));
		} catch (SQLException e) {

			return this.getReset();
		} catch (Exception e) {

			System.out.println(e);
		}

		return myRecord;
	}

	public Assignment02Record getPrevious() {

		Assignment02Record myRecord = new Assignment02Record();

		try { 	// Attempts to call resultSet.previous method to move cursor backward one row in
				// the resultset object
			resultSet.previous();

			myRecord.setFirstName(resultSet.getString(resultSet.findColumn("FIRSTNAME")));
			myRecord.setLastName(resultSet.getString(resultSet.findColumn("LASTNAME")));
			myRecord.setCity(resultSet.getString(resultSet.findColumn("CITY")));
			myRecord.setState(resultSet.getString(resultSet.findColumn("STATE")));
			myRecord.setZip(resultSet.getString(resultSet.findColumn("ZIP")));
		} catch (SQLException e) {

			return this.getLast();
		} catch (Exception e) {

			System.out.println(e);
		}

		return myRecord;
	}

	public Assignment02Record getLast() {

		Assignment02Record myRecord = new Assignment02Record();

		try { 	// Attempts to call resultSet.next method to move cursor to last row in the
				// resultset object
			resultSet.last();

			myRecord.setFirstName(resultSet.getString(resultSet.findColumn("FIRSTNAME")));
			myRecord.setLastName(resultSet.getString(resultSet.findColumn("LASTNAME")));
			myRecord.setCity(resultSet.getString(resultSet.findColumn("CITY")));
			myRecord.setState(resultSet.getString(resultSet.findColumn("STATE")));
			myRecord.setZip(resultSet.getString(resultSet.findColumn("ZIP")));
		} catch (Exception e) {

			System.out.println(e);
		}

		return myRecord;
	}

	public void close() {

		try { // Attempts to close statement and connection interface sessions
			stmt.close();
			con.close();
		} catch (SQLException e) {

			System.out.println("Connection close failed");
		}
	}

	public static void main(String args[]) {

		Assignment02SelectData selectMyData = new Assignment02SelectData();

		System.out.println(selectMyData.getReset());
		System.out.println(selectMyData.getLast());

		selectMyData.close();
	}
}
