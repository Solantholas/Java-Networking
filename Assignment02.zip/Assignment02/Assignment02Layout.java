/* Corey Hicks
 * 27 May 2018
 * CIS 404
 * 
 * Create a Swing application that looks and behaves like the example located at the top of this assignment. 
 * Start with your code from week one and implement the use of the Oracle database in place of the array 
 * used in week one. The functionality you are looking for is the following:
 * 
 * 1 Modify your CLASSPATH environment variable to include both the Oracle thin drivers .jar file and the 
 * current working directory.
 * 2 Load the Oracle Thin Drivers
 * 3 Create a connection to the Oracle database.
 * 4 Execute a query of the database to retrieve a populated ResultSet.
 * 
 * Then with the populated ResultSet:
 * 
 * The Previous button will iterate through the ResultSet moving to the previous element each time the button 
 * is clicked and will then update the GUI with the newly selected data. If the Previous button is selected 
 * while the ResultSet is positioned at the first element, your program should then move the last element and 
 * update the display with the newly selected data.
 * 
 * The Next button will iterate through the ResultSet moving to the next element each time the button is 
 * clicked and will then update the GUI with the newly selected data. If the Next button is selected while 
 * the ResultSet is positioned at the last element, your program should then move the first element and 
 * update the display with the newly selected data. 
 * 
 * When the Reset button is selected you should move to the first element in the ResultSet and update the 
 * display. 
 * 
 * This class for creating a Jframe GUI and method calling.*/

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Assignment02Layout extends JFrame {

	//Initialize new SelectData object
	Assignment02SelectData selectData = new Assignment02SelectData();

	//Instantiation of JButton, text, and label fields
	private JButton btnPrevious = new JButton("Prev");
	private JButton btnReset = new JButton("Reset");
	private JButton btnNext = new JButton("Next");
	private JTextField txtFirstName = new JTextField();
	private JTextField txtLastName = new JTextField();
	private JTextField txtCity = new JTextField();
	private JTextField txtState = new JTextField();
	private JTextField txtZip = new JTextField();
	private JLabel lblFirstName = new JLabel("First Name");
	private JLabel lblLastName = new JLabel("Last Name");
	private JLabel lblCity = new JLabel("City");
	private JLabel lblState = new JLabel("State");
	private JLabel lblZip = new JLabel("Zip");
	private JLabel lblHeader = new JLabel("Database Browser", JLabel.CENTER);

	//Action listener methods
	private ActionListener buttonListener = new ActionListener() {

		public void actionPerformed(ActionEvent e) {

			String buttonSelected = ((JButton) e.getSource()).getText();

			//Logic statements to call appropriate SelectData methods
			if (buttonSelected.equals("Prev")) {

				update(selectData.getPrevious());
			}

			if (buttonSelected.equals("Reset")) {

				update(selectData.getReset());
			}

			if (buttonSelected.equals("Next")) {

				update(selectData.getNext());
			}
		}
	};

	public Assignment02Layout() {

		//sets Java window header
		super("Database Browser");

		//Sets all text fields to uneditable
		txtFirstName.setEditable(false);
		txtLastName.setEditable(false);
		txtCity.setEditable(false);
		txtState.setEditable(false);
		txtZip.setEditable(false);
	}

	public void launchJFrame() {

		//Calls SelectData reset method to display first database row on launch
		update(selectData.getReset());
		
		// adds variables and Jframe object to the Jframe
		setSize(400, 350);
		JPanel cp = (JPanel) getContentPane();
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		cp.setLayout(null);
		cp.setBackground(Color.white);

		cp.add(btnPrevious);
		cp.add(btnReset);
		cp.add(btnNext);
		cp.add(txtFirstName);
		cp.add(txtLastName);
		cp.add(txtCity);
		cp.add(txtState);
		cp.add(txtZip);
		cp.add(lblHeader);
		cp.add(lblFirstName);
		cp.add(lblLastName);
		cp.add(lblCity);
		cp.add(lblState);
		cp.add(lblZip);

		//Sets boundaries for each Jframe object
		btnPrevious.setBounds(30, 250, 80, 25);
		btnReset.setBounds(150, 250, 80, 25);
		btnNext.setBounds(270, 250, 80, 25);
		txtFirstName.setBounds(120, 80, 250, 25);
		txtLastName.setBounds(120, 110, 250, 25);
		txtCity.setBounds(120, 140, 250, 25);
		txtState.setBounds(120, 170, 250, 25);
		txtZip.setBounds(120, 200, 250, 25);
		lblFirstName.setBounds(10, 80, 80, 25);
		lblLastName.setBounds(10, 110, 80, 25);
		lblCity.setBounds(10, 140, 80, 25);
		lblState.setBounds(10, 170, 80, 25);
		lblZip.setBounds(10, 200, 80, 25);
		lblHeader.setFont(new Font("TimesRoman", Font.BOLD, 24));
		lblHeader.setBounds(40, 10, 300, 50);

		setVisible(true);

		//Add window listener to call shutdown method when the closing X is pressed
		addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent evt) {
				shutDown();
			}
		});

		//Calls for action listeners
		btnPrevious.addActionListener(buttonListener);
		btnReset.addActionListener(buttonListener);
		btnNext.addActionListener(buttonListener);
	}

	//Method to call get/sets from Record class and assign them to Jframe objects
	private void update(Assignment02Record record) {

		txtFirstName.setText(record.getFirstName());
		txtLastName.setText(record.getLastName());
		txtCity.setText(record.getCity());
		txtState.setText(record.getState());
		txtZip.setText(record.getZip());
	}

	//Shutdown method for when closing X is pressed
	private void shutDown() {

		int returnVal = JOptionPane.showConfirmDialog(this, "Are you sure you want to quit?");

		if (returnVal == JOptionPane.YES_OPTION) {

			System.exit(0);
		}
	}

	//Main method calls Initializes new layout object and calls Launch Jframe method
	public static void main(String[] args) {

		Assignment02Layout layout = new Assignment02Layout();
		layout.launchJFrame();

	}
}