/* Create a servlet that reads an ascii file and sends the output to the browser 
that invokes the servlet. Name your ASCII file c:\temp\servlet1.dat. You must 
locate it in the c:\temp directory to receive credit. This is so I can run and 
grade it on my computer without modifying your source code. Hint: use the file 
I/O examples we covered previously and use absolute file paths. A good file to 
read is the source code to your program! Attach your servlet source code file 
and data file to this assignment in one zipped file. Do not copy (cut and paste) 
any example code, create your own code and use the examples as a guide. */

package Assignment03;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.*;
import java.util.*;
import java.nio.file.*;

@WebServlet(name = "FileReadWrite", urlPatterns = {"/FileReadWrite"})
public class FileReadWrite extends HttpServlet {

    //doGet override for file retrieval to the HTML page
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=US-ASCII");

        //print writer object for handling the printing to the HTML page
        try (PrintWriter out = response.getWriter()) {

            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet FileReadWrite</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet File Read Write</h1>");
            out.println("<div>");

            readAndWrite(out);

            out.println("</div>");
            out.println("</body>");
            out.println("</html>");
        } catch (Exception e) {
            System.out.println(e);
        }      
    }
        
    private void readAndWrite (PrintWriter out) {
        try {

            //sets path to temp folder and servlet1.dat
            Path source = Paths.get("C:/Temp/servlet1.dat");

            //reads all lines in the .dat file
            List<String> lineReader = Files.readAllLines(source);

            //writes all lines from the .datfile to the HTML page
            if (lineReader != null) {

                for (String line : lineReader) {

                    out.println(line + "<br />\n");
                }
            }
        } catch (IOException e) {
            System.out.println(e);
        }
    }
}
